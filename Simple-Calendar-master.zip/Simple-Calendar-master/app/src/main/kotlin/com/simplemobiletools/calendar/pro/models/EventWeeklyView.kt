package com.simplemobiletools.calendar.pro.models

import android.util.Range

data class EventWeeklyView(val id: Long, val range: Range<Int>)
