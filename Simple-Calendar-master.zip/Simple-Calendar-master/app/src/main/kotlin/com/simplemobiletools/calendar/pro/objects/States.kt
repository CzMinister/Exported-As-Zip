package com.simplemobiletools.calendar.pro.objects

object States {
    var isUpdatingCalDAV = false
}
