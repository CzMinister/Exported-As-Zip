package com.simplemobiletools.calendar.pro.models

data class EventRepetition(val repeatInterval: Int, val repeatRule: Int, val repeatLimit: Long)
